@echo off
cd /d "%~dp0"
title StepFund Development
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start-development.ps1"
if errorlevel 1 pause
